# Bugs

For information about open DocBook XSL2 stylesheets bugs, see the following:

- https://github.com/docbook/xslt20-stylesheets/issues
- http://sourceforge.net/tracker/?atid=373747&group_id=21935&func=browse
- http://sourceforge.net/tracker/?atid=516914&group_id=21935&func=browse
